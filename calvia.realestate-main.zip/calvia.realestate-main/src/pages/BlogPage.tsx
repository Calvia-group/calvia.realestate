import { Clock, ArrowRight } from 'lucide-react';
import { useScrollReveal } from '../hooks/useScrollReveal';
import { usePageMeta } from '../hooks/usePageMeta';
import { blogPosts } from '../data/blogPosts';
import Footer from '../components/Footer';
import type { Route } from '../hooks/useRouter';

interface BlogPageProps {
  navigate: (to: Route) => void;
}

function BlogCard({ post, index, navigate }: { post: typeof blogPosts[number]; index: number; navigate: (to: Route) => void }) {
  const { ref, isVisible } = useScrollReveal(0.05);

  return (
    <div
      ref={ref}
      className={`group cursor-pointer transition-all duration-700 ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
      }`}
      style={{ transitionDelay: `${(index % 3) * 100}ms` }}
      onClick={() => navigate(`/blog/${post.slug}` as Route)}
    >
      <div className="bg-white rounded-xl overflow-hidden border border-beige-dark/30 hover:shadow-xl hover:shadow-black/8 hover:border-dark-blue/20 transition-all duration-300 h-full flex flex-col">
        <div className="relative overflow-hidden aspect-[16/10]">
          <img
            src={post.featuredImage}
            alt={post.featuredImageAlt}
            loading="lazy"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        </div>
        <div className="p-6 flex flex-col flex-1">
          <div className="flex items-center gap-3 text-xs text-grey-light mb-3">
            <time dateTime={post.publishDate}>
              {new Date(post.publishDate).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
            </time>
            <span className="w-1 h-1 rounded-full bg-grey-light" />
            <span className="flex items-center gap-1">
              <Clock className="w-3 h-3" />
              {post.readTime}
            </span>
          </div>
          <h2 className="font-heading text-xl font-bold text-black mb-3 group-hover:text-dark-blue transition-colors leading-snug">
            {post.title}
          </h2>
          <p className="text-grey text-sm leading-relaxed mb-4 flex-1">
            {post.excerpt}
          </p>
          <span className="inline-flex items-center gap-1.5 text-dark-blue font-semibold text-sm group-hover:gap-3 transition-all duration-300">
            Read More
            <ArrowRight className="w-4 h-4" />
          </span>
        </div>
      </div>
    </div>
  );
}

export default function BlogPage({ navigate }: BlogPageProps) {
  usePageMeta({
    title: 'Calvia Real Estate Blog | Property Guides & Market Insights | Mallorca',
    description: 'Expert property guides, market insights, and essential information for buyers and home owners in Calvia, Mallorca. Neighbourhood guides, tax advice, and more.',
    keywords: 'Calvia real estate blog, Mallorca property guides, Calvia market insights, buy sell property Mallorca',
  });

  return (
    <>
      <section className="pt-28 pb-20 md:pt-36 md:pb-28 bg-warm-grey min-h-screen">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-16">
            <span className="inline-block text-dark-blue font-semibold text-sm tracking-[0.15em] uppercase mb-3">
              Insights &amp; Guides
            </span>
            <h1 className="font-heading text-3xl md:text-4xl lg:text-5xl font-bold text-black mb-4">
              Calvia Real Estate Blog
            </h1>
            <p className="text-grey text-lg max-w-2xl mx-auto leading-relaxed">
              Expert tips, market insights, and essential guides for property buyers
              and home owners in Calvi&agrave;, Mallorca.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {blogPosts.map((post, i) => (
              <BlogCard key={post.slug} post={post} index={i} navigate={navigate} />
            ))}
          </div>
        </div>
      </section>
      <Footer navigate={navigate} />
    </>
  );
}
