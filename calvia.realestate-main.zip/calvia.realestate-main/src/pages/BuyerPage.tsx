import { Home, Search, Clock, Shield, ArrowRight } from 'lucide-react';
import BuyerSection from '../components/BuyerSection';
import ProcessSteps from '../components/ProcessSteps';
import FAQSection from '../components/FAQSection';
import RecommendedReading from '../components/RecommendedReading';
import Footer from '../components/Footer';
import { useScrollReveal } from '../hooks/useScrollReveal';
import { usePageMeta } from '../hooks/usePageMeta';
import { buyerFaqs } from '../data/buyerFaqs';
import { blogPosts } from '../data/blogPosts';
import type { Route } from '../hooks/useRouter';

interface BuyerPageProps {
  onComplete: (refCode: string) => void;
  navigate: (to: Route) => void;
}

const BUYER_BLOG_SLUGS = [
  'lex-beckham-ruling-mallorca',
  'buying-property-bendinat-guide',
  'buying-villas-calvia-mallorca',
];

const BENEFITS = [
  {
    icon: Search,
    title: 'Curated Agency Matching',
    description: 'We don\'t just list agencies. We handpick the one best suited to your specific requirements \u2014 villa specialist, investment advisor, or relocation expert.',
  },
  {
    icon: Clock,
    title: 'Save Weeks of Searching',
    description: 'Skip the research, cold calls, and dead ends. Share your criteria once and we do the legwork so you can focus on finding your dream property.',
  },
  {
    icon: Shield,
    title: 'Vetted Local Experts Only',
    description: 'Every agency in our network is established in Calvi\u00E0 with a proven track record. You get quality introductions, not random listings.',
  },
];

export default function BuyerPage({ onComplete, navigate }: BuyerPageProps) {
  const { ref: heroRef, isVisible: heroVisible } = useScrollReveal(0.1);
  const { ref: benefitsRef, isVisible: benefitsVisible } = useScrollReveal(0.1);

  usePageMeta({
    title: 'Buy or Rent Property in Calvia, Mallorca | Property Matching | Calvia Real Estate',
    description: 'Looking to buy or rent property in Calvia, Mallorca? Share your criteria and get matched to the best local estate agencies instantly. Villas, apartments, fincas in Bendinat, Santa Ponsa, Son Vida and more.',
    keywords: 'buy property Calvia, rent property Calvia, Mallorca real estate, villas Calvia, apartments Santa Ponsa, Bendinat property, Son Vida real estate, rent house Mallorca',
  });

  const recommendedPosts = blogPosts.filter((p) => BUYER_BLOG_SLUGS.includes(p.slug));

  return (
    <>
      <section className="pt-28 pb-16 md:pt-36 md:pb-20 bg-beige">
        <div
          ref={heroRef}
          className={`max-w-4xl mx-auto px-6 text-center transition-all duration-700 ${
            heroVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-dark-blue/10 mb-6">
            <Home className="w-8 h-8 text-dark-blue" />
          </div>
          <h1 className="font-heading text-4xl md:text-5xl font-bold text-black mb-5 leading-tight">
            Find Your Dream Home in Calvi&agrave;
          </h1>
          <p className="text-lg md:text-xl text-grey-dark max-w-2xl mx-auto leading-relaxed mb-3">
            Whether you want to buy or rent, tell us what you are looking for. Our team personally finds
            the ideal agency to help you &mdash; then connects you directly.
          </p>
          <p className="text-base text-grey max-w-xl mx-auto">
            You choose how: WhatsApp, email, or phone call. Your preference, your pace.
          </p>
          <div className="mt-8">
            <button
              onClick={() => document.getElementById('buyer-form')?.scrollIntoView({ behavior: 'smooth' })}
              className="inline-flex items-center gap-2 px-8 py-3.5 bg-dark-blue text-white font-semibold rounded-lg text-lg transition-all duration-300 hover:bg-dark-blue-light hover:shadow-[0_0_30px_rgba(0,31,63,0.3)] hover:-translate-y-0.5"
            >
              Start Your Search
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </section>

      <section className="py-16 md:py-24 bg-white">
        <div className="max-w-5xl mx-auto px-6">
          <ProcessSteps variant="buyer" />
        </div>
      </section>

      <section className="py-16 md:py-20 bg-beige/50">
        <div
          ref={benefitsRef}
          className={`max-w-5xl mx-auto px-6 transition-all duration-700 ${
            benefitsVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          <div className="text-center mb-12">
            <h3 className="font-heading text-2xl md:text-3xl font-bold text-black mb-3">
              Why Use Calvia Real Estate?
            </h3>
            <p className="text-grey max-w-lg mx-auto">
              We are not an agency. We are the bridge that gets you to the right one, fast.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {BENEFITS.map((benefit) => (
              <div
                key={benefit.title}
                className="bg-white rounded-xl p-7 border border-beige-dark/40 hover:shadow-lg hover:shadow-black/5 hover:border-dark-blue/20 transition-all duration-300"
              >
                <benefit.icon className="w-7 h-7 text-dark-blue mb-4" />
                <h4 className="font-bold text-black text-lg mb-2">{benefit.title}</h4>
                <p className="text-grey text-[15px] leading-relaxed">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="buyer-form" className="py-16 md:py-24 bg-beige">
        <div className="max-w-4xl mx-auto px-6">
          <div className="text-center mb-10">
            <h3 className="font-heading text-2xl md:text-3xl font-bold text-black mb-3">
              Share Your Criteria
            </h3>
            <p className="text-grey max-w-lg mx-auto">
              Takes under 2 minutes. The more detail you provide, the better we can match you.
            </p>
          </div>
          <BuyerSection onComplete={onComplete} />
        </div>
      </section>

      <FAQSection
        title="Frequently Asked Questions"
        subtitle="Everything you need to know about buying or renting property in Calvia, Mallorca."
        faqs={buyerFaqs}
        schemaId="buyer"
      />

      <RecommendedReading posts={recommendedPosts} navigate={navigate} />

      <Footer navigate={navigate} />
    </>
  );
}
